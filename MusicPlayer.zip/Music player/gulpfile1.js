/*
function defaultTask(cb) {
    console.log('万鑫伦');
    cb();
}
exports.default = defaultTask;*/

//公开任务  私有任务
/*const {series,parallel} = require("gulp");
function fn1(cb) {
    console.log('fn1被调用了');
    cb();
}
function fn2(cb) {
    console.log('fn2被调用了');
    cb();
}
exports.default = series(fn1,fn2);
exports.default = parallel(fn1,fn2);*/

//处理文件
const {src,dest} = require("gulp");
const uglify = require("gulp-uglify");
const rename = require("gulp-rename");
exports.default= function () {
    return src("./src/js/*.js")
        .pipe(dest("./dist/js"))
        .pipe(uglify())
        .pipe(rename({extname:".min.js"}))
        .pipe(dest("./dist/js"));
}

//文件监控
const {watch} = require("gulp");
watch("./src/css/*",{
    delay:2000
},function (cb) {
    console.log('文件被修改了');
    cb();

})
