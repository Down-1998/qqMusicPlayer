//渲染模块功能:渲染图片音乐信息,是否喜欢
;(function (root) {
    //渲染图片
    function renderImg(src) {
        root.blurImg(src)//给body添加背景
        let img = document.querySelector('.songImg img');
        img.src = src;
    }

    //渲染音乐信息
    function renderInfo(data) {
        var songInfo = document.querySelector('.songInfo').children;
        songInfo[0].innerHTML = data.name;
        songInfo[1].innerHTML = data.singer;
        songInfo[2].innerHTML = data.album;
    }

    //渲染是否喜欢
    function renderisLiking(isLike) {
        var lis = document.querySelectorAll('.control li');
        lis[0].className = isLike? "liking" :"";
        // console.log(isLike);

    }

    root.render = function (data) {//data为请求过来的数据
        renderImg(data.image);
        renderInfo(data);
        renderisLiking(data.isLike);
    }
})(window.player || (window.player = {}));