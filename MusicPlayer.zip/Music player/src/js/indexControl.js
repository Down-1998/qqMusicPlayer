;(function (root) {
    function Index(len) {
        this.index = 0;//当前的索引值为0
        this.len = len;//数据的长度
    }
    Index.prototype = {
        //取上一首的索引
        prev(){
            return this.get(-1);//切上一首
        },
        //下一首的索引
        next(){
            return this.get(1);//切下一首
        },
        //用来获取索引,参数为+1或者-1
        get(val){
            this.index = (this.index + val + this.len) % this.len;
            return this.index;
        }
    }
    root.controlIndex = Index;//把构造函数暴露出去
})(window.player || (window.player = {}));