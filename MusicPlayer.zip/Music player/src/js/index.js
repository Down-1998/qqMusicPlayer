;(function ($,player) {
    function MusicPlayer(dom) {
        this.wrap = dom;//播放器的容器(用于加载listControl的模块)
        this.dataList = [];//存储获取请求到的数据
        // this.now = 0;//歌曲索引
        this.indexobj = null;//索引值对象(用于切歌)
        this.rotateTimer = null;
        this.curIndex = 0;//当前播放歌曲的索引值
        this.list = null;//列表切歌对象(在listplay中赋值)
        this.progress = player.progress.pro();
    }
    MusicPlayer.prototype = {
        init:function(){
            this.getDom();
            this.getData('../mock/data.json');
        },
        getDom:function(){//获取页面里的元素
            this.record = document.querySelector('.songImg img');//旋转图片
            this.controlBtns = document.querySelectorAll('.control li');//底部导航里的按钮
        },
        getData:function(url) {
            var This = this;
            $.ajax({
                url:url,
                method:"get",
                success:function (data) {
                    This.dataList = data;//存储请求过来的数据表
                    This.listPlay();//列表切歌要放在lodMusic的前面
                    This.indexobj = new player.controlIndex(data.length);//给索引值对象赋值
                    This.loadMusic(This.indexobj.index);//加载音乐
                    This.musicControl();//添加音乐操纵功能
                    This.dragProgress();//进度条拖拽功能
                    console.log(data);
                },
                error:function () {
                    console.log('数据请求失败');
                }
            })
        },
        loadMusic:function(index){//加载音乐的
            player.render(this.dataList[index]);//渲染相应音乐图片歌曲信息
            player.music.load(this.dataList[index].audioSrc);
            this.progress.renderAllTime(this.dataList[index].duration);

            //播放音乐
            if (player.music.status == 'play'){
                player.music.play();
                this.controlBtns[2].className = 'playing';//把按钮变为播放
                this.imgRotate(0);//切歌的时候旋转
                this.progress.move(0);
            }
            //改变列表里歌曲的选中状态
            this.list.changeSelect(index);
            this.curIndex = index;//存储当前歌曲对应的索引值
        },
        musicControl:function(){//控制音乐的上一首  下一首
            var This = this;
            //上一首
            this.controlBtns[1].addEventListener('touchend',function () {
                player.music.status = 'play';
                // This.now--;
                This.loadMusic(This.indexobj.prev());
            });

            //播放与暂停
            this.controlBtns[2].addEventListener('touchend',function () {
               if (player.music.status == 'play'){//当前状态为播放,点击后要暂停
                   player.music.pause();//歌曲暂停
                   this.className = "";//按钮变成暂停状态
                   player.music.status = 'pause';
                   This.imgStop();//停止唱片旋转
                   This.progress.stop();
               }else {
                   player.music.play();
                   this.className = 'playing';
                   player.music.status = 'play';
                   var deg = This.record.dataset.rotate || 0;
                   This.imgRotate(deg);//开始播放的时候旋转
                   This.progress.move();
               }
            })
            //下一首
            this.controlBtns[3].addEventListener('touchend',function () {
                player.music.status = 'play';
                // This.now++;
                This.loadMusic(This.indexobj.next());
            })
        },

        //图片旋转
        imgRotate:function(deg){
            var This = this;
            clearInterval(this.rotateTimer);
            this.rotateTimer = setInterval(function () {
                deg = +deg +0.2;//前面的加号是将其转成数字
                This.record.style.transform = `rotate(${deg}deg)`;
                This.record.dataset.rotate = deg;//将旋转的角度存储到标签上,为了暂停后再次旋转时能取到
            },1000/60);
        },
        imgStop:function(){//停止唱片旋转
            clearInterval(this.rotateTimer);
        },
        listPlay:function(){//列表切歌功能
            let This = this;
            this.list = player.listControl(this.dataList,this.wrap);//把listControl的对象的值赋给this.list
            this.controlBtns[4].addEventListener('touchend',function () {
                    This.list.slideUp();
            });

            //歌曲列表添加事件
            this.list.musicList.forEach((item,index)=>{
                item.addEventListener("touchend",function () {
                    //如果点击的是当前的那首歌,不管它是暂停还是播放都无效
                    if (This.curIndex == index){
                        return;
                    }
                    player.music.status = 'play';//歌曲状态变成播放
                    This.indexobj.index = index;//索引值对象的身上的当前索引值要更新
                    This.loadMusic(This.indexobj.index);
                    This.list.slideDown();
                })
            })
        },
        dragProgress(){
            let This = this;
            let circle = player.progress.drag(document.querySelector('.circle'));
            circle.start = function () {
                This.progress.stop();
                // console.log(123)
            }

            circle.move = function (per) {
                This.progress.update(per);
            }

            circle.end = function (per) {
                let cutTime = per * This.dataList[This.indexobj.index].duration;
                player.music.playTo(cutTime);
                player.music.play();
                This.progress.move(per);
                var deg = This.record.dataset.rotate || 0;
                This.imgRotate(deg);//开始播放的时候旋转
                This.controlBtns[2].className = 'playing';//把按钮变为播放
            }
        }
    }
    var musicplayer = new MusicPlayer(document.getElementById('wrap'));
    musicplayer.init();
})(window.Zepto,window.player)