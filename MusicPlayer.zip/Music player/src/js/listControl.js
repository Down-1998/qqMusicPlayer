;(function (root) {
    function listControl(data,wrap) {
       let list = document.createElement('div');
       let dl = document.createElement('dl');
       let dt = document.createElement('dt');
       let close = document.createElement('div');
       let musicList = [];//存储所有的歌曲对应的dom
        list.className = 'list';
        dt.innerHTML = "播放列表";
        close.className = "close";
        close.innerHTML = "关闭";
        dl.appendChild(dt);
        data.forEach((item,index)=>{
            let dd = document.createElement('dd');
            dd.innerHTML = item.name;
            dd.addEventListener("touchend",function () {
                changeSelect(index);
            })
            dl.appendChild(dd);
            musicList.push(dd);
        });
        list.appendChild(dl);
        list.appendChild(close);
        wrap.appendChild(list);
        changeSelect(0);//默认刚开始第0个是选中的状态
        let disY = list.offsetHeight;
        list.style.transform = `translateY(${disY}px)`;

        //关闭按钮
        close.addEventListener('touchend',slideDown);
        //列表滑动显示
        function slideUp() {
            list.style.transition = `all 0.2s`;
            list.style.transform = `translateY(0)`;
        }
        //列表滑动隐藏
        function slideDown() {
            list.style.transition = `all 0.2s`;
            list.style.transform = `translateY(${disY}px)`;
        }

        //切换选中元素
        function changeSelect(index) {
            for (let i = 0; i < musicList.length; i++){
                musicList[i].className = '';
            }
            musicList[index].className = 'active';
        }
        return {
            dom:list,
            musicList:musicList,
            slideUp:slideUp,
            slideDown:slideDown,
            changeSelect:changeSelect
        }
    }

    root.listControl = listControl;
})(window.player || (window.player = {}));